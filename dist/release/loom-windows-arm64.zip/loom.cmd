@echo off
set SCRIPT_DIR=%~dp0
node "%SCRIPT_DIR%loom.mjs" %*
